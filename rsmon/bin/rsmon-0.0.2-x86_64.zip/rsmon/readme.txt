ダウンロード

 64bit Windows

  bin/rsmon-*-x86_64.zip

必要要件

 1. JRE7以降がインストールされていること

  http://java.com/ja/download/

 2. WinPcapがインストールされていること

  http://www.winpcap.org/
