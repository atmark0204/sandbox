必要要件

 １．JRE7以降がインストールされていること

  http://java.com/ja/download/

 ２．環境変数 JAVA_HOME が設定されていること

 ３．WinPcapがインストールされていること

  http://www.winpcap.org/
