ダウンロード

 32bit Windows (動作未確認)

  bin/rsmon-*-x86.zip

 64bit Windows

  bin/rsmon-*-x86_64.zip

必要要件

 1. JRE7以降がインストールされていること

  http://java.com/ja/download/

 2. 環境変数 JAVA_HOME が設定されていること

 3. WinPcapがインストールされていること

  http://www.winpcap.org/
