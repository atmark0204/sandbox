ダウンロード

 32bit Windows (動作未確認)

  bin/chatlogger-*-x86.zip

 64bit Windows

  bin/chatlogger-*-x86_64.zip

必要要件

 １．JRE7以降がインストールされていること

  http://java.com/ja/download/

 ２．環境変数 JAVA_HOME が設定されていること

 ３．WinPcapがインストールされていること

  http://www.winpcap.org/

 ４．item.datがプログラムと同じディレクトリに配置されていること

既知の不具合

 ・チャット関連の取得漏れ（パターン漏れ）
 ・拾得アイテムに取得漏れがある可能性がある（パターン漏れ）
 ・拾得アイテム名に不明なものがある（item.datがすべて解析出来ていない為）
 ・そこそこスペックのあるマシンでないと動作が重い