ダウンロード

 32bit Windows (動作未確認)

  bin/pblogger-*-x86.zip

 64bit Windows

  bin/pblogger-*-x86_64.zip

必要要件

 1. JRE7以降がインストールされていること

  http://java.com/ja/download/

 2. 環境変数 JAVA_HOME が設定されていること

 3. WinPcapがインストールされていること

  http://www.winpcap.org/

使用方法

 1. 比較したいログがある場合「過去データ読込」を押す

 2. 使用するネットワークデバイスとListenするIPアドレスを選択する

 3. 「開始」を押す

 4. ポイント戦を開始する

 5. 各面をクリアするごとに「*面クリア」を押す

 6. 終了後、停止する（「開始」をもう一度押す）