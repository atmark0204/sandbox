ダウンロード

 32bit Windows (動作未確認)

  bin/pblogger-*-x86.zip

 64bit Windows

  bin/pblogger-*-x86_64.zip

必要要件

 １．JRE7以降がインストールされていること

  http://java.com/ja/download/

 ２．環境変数 JAVA_HOME が設定されていること

 ３．WinPcapがインストールされていること

  http://www.winpcap.org/

使用方法

 １． 比較したいログがある場合「過去データ読込」を押す

 ２． 使用するネットワークデバイスとListenするIPアドレスを選択する

 ３． 「開始」を押す

 ４． ポイント戦を開始する

 ５． 各面をクリアするごとに「*面クリア」を押す

 ６． 終了後、停止する（「開始」をもう一度押す）